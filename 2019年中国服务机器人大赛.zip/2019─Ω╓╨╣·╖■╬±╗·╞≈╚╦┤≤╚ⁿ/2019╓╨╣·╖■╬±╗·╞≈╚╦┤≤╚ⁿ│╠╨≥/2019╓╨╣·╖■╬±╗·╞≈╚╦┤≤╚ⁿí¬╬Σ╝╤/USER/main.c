/*****************************************************************************
Copyright: 2019-2029, ���ɹŹ�ҵ��ѧ@Inner Mongol University of Technology
Project name: ��
Description: 2019���й���������˴���
Programmer:��� ���ٶ�
Mechanical structure author:��Ӣ��
Version: 1.0
Date: 2019/6/1
History: None
*****************************************************************************/

#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"	 
#include "adc.h"
#include "timer.h"
#include "beep.h"
#include "move.h"
#include "oled.h"
#define Target_position 17

/************************************************
 
************************************************/
int N=0;
int B=0;
int Q=0;
int W=0;
int E=0;
int i=1;
u16 choice;
int main(void)
{	 
  int c;
  int  d,pid,adc13,pwm4,m;
  u16 adc10,pwm1,pwm2,pwm3,adc14,z,adc12,w,j;
	
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200
 	LED_Init();			     //LED�˿ڳ�ʼ��		 	
 	Adc_Init();		  		//ADC��ʼ��
  OLED_Init_NO_1();
	TIM3_PWM_Init(99,36);///////////���̵��/////////
	TIM2_PWM_Init(1999,719);////////���/////////////
	TIM4_PWM_Init(250,36);////L298N PWM��ʼ��////////

	while(1)
	{
	 	//OLED_Clear_NO_1();
//	    OLED_ShowString_NO_1(0,10,"adc1",12);
//	    OLED_ShowString_NO_1(0,20,"adc2",12);
//	    OLED_ShowString_NO_1(0,20,"adc3",12);
		OLED_ShowString_NO_1(0,10,"adcB",12);
//		OLED_ShowString_NO_1(0,20,"adc5",12);
		OLED_ShowString_NO_1(0,20,"adcF",12);
	    OLED_ShowString_NO_1(0,50,"PID=-",12);		
		OLED_ShowString_NO_1(0,40,"PID=+",12);	
		OLED_ShowString_NO_1(0,30,"PWM=",12);
	}	
		
			 while(1)
	{
		  adc10=Get_Adc_Average(ADC_Channel_10,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
		  OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
     
				 
	}
		
		
//////////////////����·��ѡ��//////////////////////

	      while(1)
		{
		if(gray_l==0)
		{
		delay_ms(200);
			if(gray_l==0)
			{
				choice=0;break;
			}
		}
		if(gray_r==0)
		 {
		delay_ms(80);
			if(gray_r==0)
			{
				choice=1;break;
			}
		 }
		}
	
///////////////////��ʼ////////////////////////////
while(1)
{
	down(); 
	if(key1==0)
	{
		stopk1();
		open();
		break;
	}
}
while(1)
{
	
 findline();//������ȫ��ѭ��ִ��
 if(i==1)////���м������Է����޸ĳ���
 {
	i++;
	while(1)
	{
	 medium_go(40);
	 if(gray_a2==1&&gray_a11==1)	
	 {
		medium_go(30);
		delay_ms(150);  
		break;
	 }
	}
	
	while(1)
	{
     findline();	
	 if(gray_a4==1&&gray_a7==1)
	 {
		 delay_ms(5);
	 if(gray_a4==1&&gray_a7==1)
	  {     
	  stop();
	  delay_ms(100);//������ʱ���ԣ�����ת���ٶ�
	  Turn_L_Cross();
	    break;
	  }
	 }
	}
 }
///////////////////////////��ǰѰǽ/////////////////
 if(i==2)	 
  {
 i++;
	 while(1)
	 {
		 findline();
		 if(gray_a2==1&&gray_a11==1)//////&&�����Կ��� ע�⣺������Ҫ���м�Ҷȣ��ᷢ������
		 {
		 break;
		 } 
	 }
	 while(1) 
	 {
	 stop();
	 delay_ms(100);//������ʱ���ԣ�����ת��
	 Turn_R_Cross_x();
		 
	   break;	
	 }	 

	   while(1)
	{
     medium_go(30);
	 delay_ms(1000);////////�����ٶȲ��ԣ�����
	 delay_ms(500);
		break;
	}
	
	 while(1)
	{
		  adc10=Get_Adc_Average(ADC_Channel_10,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
		  OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
     
          c=28-adc10;///////////////////28,���е���
		
		if(adc10>26)
		{
		c=-3;
		}
		  z=c*5;
		  pwm1=27+z;//////////27���е���
	      go_wall1(pwm1);

				 if(gray_a2==1&&gray_a11==1)
				 {
				  while(1)
				  {
					  stop();
						delay_ms(100);
						break;	 
				  }break;	
				 }					 
	}
		 stop();
		 delay_ms(1000);
		 delay_ms(1000);
		 delay_ms(1000);
		 delay_ms(1000);
		 delay_ms(1000);
 }	 
///////////////���Ѳǽ//////////////////////
 if(i==3)
{	
i++;	  
	    while(1)////////////////////////����Ѱǽ
	   {
		 adc14=Get_Adc_Average(ADC_Channel_11,10)/56;
		 OLED_ShowNum_NO_1(50,20,adc14,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
		   
		 d=13-adc14;
		   if(adc14>16)
		   {
		   d=-3;
		   }
		  m=d*5; 
		 pwm2=27+m;	 
	     back_wall2(pwm2);	
		   
             if(adc14<5)
			 {
			 delay_ms(10);
			 if(adc14<5)
				 break;
			 }				 
	   }
       while(1)
       {	
		   medium_back(30);
		   if(gray_r==0)
		   {
		   delay_ms(5);
			if(gray_r==0)
			{
		     Turn_R_Cross_back();
		     break;  
			}				
		   }	   	   	   	   	   
	   }    
 }


if(i==4)
{
i++;
	while(1)
  {
	findline();
	if(gray_a2==1&&gray_a11==1&&gray_a3==1&&gray_a10==1)		
	{
		Q++;
		medium_go(45 );
		delay_ms(100);
	}
	if(Q==2)
	{
	while(1) 
	 {
	 stop();
	 delay_ms(500);//������ʱ���ԣ�����ת��
	 Turn_L_Cross_r();
		 	  while(1)
		  {
			  if(gray_b6==1)
			  {
			  stop();
			  delay_ms(100);
			  break;
			  }
		  }
		 break;
	 }break;
	}  
  }
}
if(i==5) 
{
i++;
  /////////////////////////��һ����ǰ��Ѳ��////////////////
     while(1)
	{
     medium_go(30);
	 delay_ms(1000);////////�����ٶȲ��ԣ�����
	 delay_ms(500);
		break;
	}
	
	 while(1)
	{
		  adc12=Get_Adc_Average(ADC_Channel_14,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
		  OLED_ShowNum_NO_1(50,30,adc12,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
     
          w=27-adc12;///////////////////27,���е���
		
		if(adc12>31)
		{
		w=-3; 
		}
		  j=w*5;
		  pwm3=27+j;//////////33���е���
	      go_wall2(pwm3);
		
		 if(gray_a2==1&&gray_a11==1)
			 {
			while(1)
			  {
			 stop();
			 delay_ms(1000);
		     delay_ms(1000);
			 delay_ms(1000);
			 delay_ms(1000); 
			 delay_ms(1000);				  
			                break;	 
			  } break;	
		     }					 
	}
}

if(i==6)
{
i++;
	////////////////////////��һ�κ�����Ѱǽ
			while(1)
	   {
		 pid=Speed_PID(adc13,Target_position);
		 adc10=Get_Adc_Average(ADC_Channel_13,10)/56;	   
         OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();		   
		 if(pid<0)
		 {
		 c=-pid*1.25;
		 OLED_ShowNum_NO_1(50,50,c,6,12);OLED_Refresh_Gram_NO_1();
		 m=pid;	 
		 pwm4=40+m;	
		 pwm_limit(pwm4);
//			 OLED_ShowNum_NO_1(50,30,pwm4,6,12);OLED_Refresh_Gram_NO_1();		 
		 }
		 if(pid>0||pid==0)
		 {
		 c=pid;
	     OLED_Refresh_Gram_NO_1();
		 OLED_ShowNum_NO_1(50,40,c,6,12);OLED_Refresh_Gram_NO_1();
		 pwm4=40+pid;	
		 pwm_limit(pwm4);
//		 OLED_ShowNum_NO_1(50,30,pwm4,6,12);OLED_Refresh_Gram_NO_1();		 
		 }    

		 
          if(adc10<=5)
		   {
		   break;
		   }			   			   
		  			 
	   }
		 while(1)
	   {
	   medium_back(30);
		   if(gray_l==0)   
		   {
			delay_ms(5);
		    if(gray_l==0)
			{
			 Turn_L_Cross_back();
			 break;
		    }

		   }
	    }   	
}

if(i==7)
{
i++;
	////////////////////////�ص����//////////////
		while(1)
	   {
		findline();
		   if(gray_a2==1&&gray_a11==1&&gray_a3==1&&gray_a10==1)
		   {
		      stop();
			  delay_ms(200);
			  Turn_L_Cross();break;
		   }
	   } 
	   while(1)
		{
		 findline();	
		 if(gray_a2==1&&gray_a11==1)
		 {
			stop();
			delay_ms(500);
			break;
		 }	
		}
}
if(choice==0)
{
if(i==8)
{
i++;
	/////////////////////������ٴγ���////////////
	while(1)
	{
	up();
		if(key2==0)
		{
		stopk1();
			open();
		break;
		}
	}
		while(1)
		{
			backline();
			if(gray_b11==1&&gray_b3==1)
			{
			stop();
		    delay_ms(100);
			Turn_L_Cross_z();break;
			}
		}
		while(1)///////////////////////////////////////////////////!!!!!!!!!!!!!!!!!!
       {
			findline();
		 if(gray_a3==1&&gray_a10==1)
			{
				delay_ms(5);
				if(gray_a3==1&&gray_a10==1)
				{
			stop();
		    delay_ms(100);
			Turn_R_Cross_b();
					break;
				}
			}
       }	   	      
}


if(i==9)
{
i++;
	/////////////////////////////////ץҩƷ//////////////
	while(1)
   {
    findline_ts();
	if(paotong1==0)
	{	
		delay_ms(500);
		stop();
		delay_ms(500);
		close();
		break;
	} 
   }
		while(1)
		{
		down();
			if(key1==0)
			{
			stopk1();
			break;
			}  
	    }	
		 while(1)
		{
		Turn_L_Cross_back_1();/////////!!!!!!���Ȳ���
			  break;
		}
		
		while(1)
		{
		  findline_ts();
			if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)
			{
			break;
			}
		}
}

/////////////////////////�ڶ�����ǰ��Ѱǽ///////////////		
if(i==10)
{
i++;			
	while(1)
	{		
     medium_go(40);
	 delay_ms(1000);////////�����ٶȲ��ԣ�����
//	 delay_ms(300);
		break;
	}
	
	 while(1)
	{
		  adc12=Get_Adc_Average(ADC_Channel_14,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
		  OLED_ShowNum_NO_1(50,30,adc12,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
     
          w=27-adc12;///////////////////���е���
		
		if(adc12>31)
		{
		w=-3; 
		}
		  j=w*5;
		  pwm3=26+j;//////////33���е���
	      go_wall2(pwm3);
		
		while(1)
		{
		 if(gray_a2==1&&gray_a11==1)
		 {
		     stop();
			 delay_ms(200);
			 open();
			 delay_ms(1000);
			 delay_ms(1000);
			 delay_ms(1000);
			 break;
		 }
		}break;				 
	}			
}

/////////////////////////�ڶ��������Ѱǽ///////////////	
 if(i==11)
{	
      i++;	  
			while(1)
	   {
		 pid=Speed_PID(adc13,Target_position);
		 adc10=Get_Adc_Average(ADC_Channel_13,10)/56;	   
         OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();		   
		 if(pid<0)
		 {
		 c=-pid*1.25;
		 OLED_ShowNum_NO_1(50,50,c,6,12);OLED_Refresh_Gram_NO_1();
		 m=pid;	 
		 pwm4=40+m;	
		 pwm_limit(pwm4);
//			 OLED_ShowNum_NO_1(50,30,pwm4,6,12);OLED_Refresh_Gram_NO_1();		 
		 }
		 if(pid>0||pid==0)
		 {
		 c=pid;
	     OLED_Refresh_Gram_NO_1();
		 OLED_ShowNum_NO_1(50,40,c,6,12);OLED_Refresh_Gram_NO_1();
		 pwm4=40+pid;	
		 pwm_limit(pwm4);
//		 OLED_ShowNum_NO_1(50,30,pwm4,6,12);OLED_Refresh_Gram_NO_1();		 
		 }    

		 
          if(adc10<=5)
		   {
		   break;
		   }			   			   
	   }  	
	   
//////////////////////////////����Ϊ�ڶ��μ���ץ��//////////////////   
	      while(1)
	   {  
	   medium_back(30);
		    if(gray_b1==1||gray_b2==1||gray_b3==1||gray_b5==1||gray_b6==1||gray_b7==1||gray_b8==1||gray_b9==1||gray_b10==1||gray_b11==1||gray_b12==1)
			{
		  while(1)
			{
				backline_ts();
				
				
				if(gray_l==0)
				{
			 stop();
			 delay_ms(500);
			 Turn_R_Cross_back_1();
				stop();
				delay_ms(100);
                  break;					
				}
		    }

			 break;
		    }
	  }
	   
	   
	   while(1)
	   {
	   up();
		  if(key2==0)
		  {
		  stopk1();
		  break;
	      }
	   }
	   
	 while(1)
     {
		findline_ts();
		if(paotong1==0)
		 {
			delay_ms(300);
			stop();
			delay_ms(500);
			close();
			delay_ms(1000);
			break;
		 }
     }
	 while(1)
	  {
		medium_back(30);
	    if(gray_r==0)
		 {
		stop();
		delay_ms(500);
		Turn_R_Cross_back_2();
			stop();
	    	delay_ms(100);
			  break;	  
		 }
	  }
	  
	   while(1)
	    {
	    down();
		   if(key1==0)
		   {
		   stopk1();
		   break;
		   }
	    }
		
		
 //////////////////////////////ץҩ����///////////////////
 	  while(1)
     {
	findline();
	if(gray_a4==1&&gray_a9==1&&gray_a3==1&&gray_a10==1)		
	{
		W++;
		medium_go(40);
		delay_ms(200);
	}
	if(W==2)
	 {
	  while(1) 
	  {
	 stop();
	 delay_ms(500);//������ʱ���ԣ�����ת��
	 Turn_R_Cross_x();
		 break;
	  }break;
	 }

    }
}	 

if(i==12)////////////////////////��ҩ/////////////////////
{	
	
i++;	  
		while(1)
		{
			medium_back(30);
			delay_ms(500);
			break;
		}
///////////////////////////////////
		while(1)
		{
		findline_ts();
			if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)
			{
			break;
			}
		} 
			   while(1)
			{
			 medium_go(40);
			 delay_ms(800);////////�����ٶȲ��ԣ�����
			 delay_ms(800);////////�����ٶȲ��ԣ�����
				break;
			}
			  while(1)
		 {
				  adc10=Get_Adc_Average(ADC_Channel_10,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
				  OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
			 
				  c=30-adc10;///////////////////23,���е���
				
				if(adc10>28)
				{
				c=-3;

				}
				  z=c*5;
				  pwm1=27+z;//////////���е���
				  go_wall1(pwm1);
				
				
			    while(1)
			{
			 if(gray_a2==1&&gray_a11==1)
			 {
				 stop();
				 delay_ms(200);
				 open();
				 delay_ms(200);
				 delay_ms(1000);
				 delay_ms(1000);
				 delay_ms(1000);
				 break;
			 }
			}break;

		 }
}

	 ///////////////�ڶ��������Ѳǽ///////////////
 if(i==13)
 {	
	
      i++;	  
	    while(1)
	   {
		 adc14=Get_Adc_Average(ADC_Channel_11,10)/56;
		 OLED_ShowNum_NO_1(50,20,adc14,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
		   
		 d=13-adc14;
		   if(adc14>16)
		   {
		   d=-3;
		   }
		  m=d*5; 
		 pwm2=27+m;	 
	     back_wall2(pwm2);	
		   
             if(adc14<5)
			 {
			 delay_ms(10);
			 if(adc14<5)
				 break;
			 }				 
	   }
   
 	      while(1)
	   {  
	   medium_back(30);
		    if(gray_b1==1||gray_b2==1||gray_b3==1||gray_b5==1||gray_b6==1||gray_b7==1||gray_b8==1||gray_b9==1||gray_b10==1||gray_b11==1||gray_b12==1)
			{
		  while(1)
			{
				backline_ts();
				
				
				if(gray_r==0)
				{
			 stop();
			 delay_ms(500);
			 Turn_R_Cross_back_1();
				stop();
				delay_ms(100);
                  break;					
				}
		    }

			 break;
		    }
	  }	   
 }

if(i==14)
{
i++;
	while(1)
  {
	findline();
	if(gray_a6==1&&gray_a11==1&&gray_a3==1&&gray_a10==1)		
	{
      stop();
	  delay_ms(500);
	  Turn_R_Cross_last();break;
	}
  }
  	  while(1)
		{
		 findline();	
		 if(gray_a6==1&&gray_a7==1&&gray_a5==1&&gray_a8==1)
		 {
			medium_go(40);
			delay_ms(1000);//////////////////////////////������ʱ������������������
			 stop();
			break;
		 }	
		}
} 

	while(1)
	{
		stop();
	}


}////choice



if(choice==1)
{

if(i==8)
{
i++;
	/////////////////////������ٴγ���////////////
	while(1)
	{
	up();
		if(key2==0)
		{
		stopk1();
			open();
		break;
		}
	}
		while(1)
		{
			backline();
			if(gray_b11==1&&gray_b3==1)
			{
			stop();
		    delay_ms(100);
			Turn_L_Cross_z();break;
			}
		}
		while(1)///////////////////////////////////////////////////!!!!!!!!!!!!!!!!!!
       {
			findline(); 
		 if(gray_a3==1&&gray_a10==1)
			{
				delay_ms(5);
				if(gray_a3==1&&gray_a10==1)
				{
			stop();
		    delay_ms(100);
			Turn_R_Cross_b();
					break;
				}
			}
       }	   	      
}

if(i==9)
{
i++;
		/////////////////////////////////ץҩƷ//////////////
	while(1)
   {
    findline_ts();
	if(paotong1==0)
	{	
		delay_ms(500);
		stop();
		delay_ms(500);
		close();
		break;
	} 
   }
		while(1)
		{
		down();
			if(key1==0)
			{
			stopk1();
			break;
			}  
	    }	
		 while(1)
		{
		medium_back(20);
			if(gray_r==0)
		 {
		   delay_ms(5);
		   if(gray_r==0) 
		  {
		stop();
		delay_ms(100);
		Turn_R_Cross_back_1();//////////////////////////////////////////////!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!���Ȳ���
			  break;
		  }
		 }
		}
		
/////////////////////////////////////////////////////
    while(1)
   {
	findline();
	if(gray_a5==1&&gray_a8==1&&gray_a3==1&&gray_a10==1)		
	{
		B++;
		medium_go(40);
		delay_ms(200);
	}
	if(B==2)
	 {
	  while(1) 
	  {
	 stop();
	 delay_ms(500);//������ʱ���ԣ�����ת��
	 Turn_R_Cross_x();
		 break;
	  }break;
	 }

   }	   	      

}


if(i==10)
{
i++;
	////////////////////�ڶ�����ǰ��Ѱǽ//////////////
		while(1)
	{
     medium_back(30);
	 delay_ms(500);////////�����ٶȲ��ԣ�����
		break;
	}
	
		 while(1)
	 {
	 findline_ts();
		 if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)
		 {
		 break;
		 }
	 } 
	
	    while(1)
		{
		 medium_go(40);
		 delay_ms(800);////////�����ٶȲ��ԣ�����
			break;
		}
	 
		while(1)
	 {
		  adc10=Get_Adc_Average(ADC_Channel_10,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
		  OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
     
          c=30-adc10;///////////////////23,���е���
		
		if(adc10>28)
		{
		c=-3;

		}
		  z=c*5;
		  pwm1=27+z;//////////���е���
	      go_wall1(pwm1);
		
		while(1)
		{
		 if(gray_a2==1&&gray_a11==1)
		 {
		     stop();
			 delay_ms(200);
			 open();
			 delay_ms(200);
			  delay_ms(1000);
			 delay_ms(1000);
			 delay_ms(1000);
			 break;
		 }
		}break;	 
						 
	 }  
}
 ///////////////�ڶ��������Ѳǽ///////////////
 if(i==11)/////������
 {	
i++;	  
	    while(1)
	   {
		 adc14=Get_Adc_Average(ADC_Channel_11,10)/56;
		 OLED_ShowNum_NO_1(50,20,adc14,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
		   
		 d=13-adc14;
		   if(adc14>16)
		   {
		   d=-3;
		   }
		  m=d*5; 
		 pwm2=27+m;	 
	     back_wall2(pwm2);	
		   
             if(adc14<5)
			 {
			 delay_ms(10);
			 if(adc14<5)
				 break;
			 }				 
	   }
	   
 	  while(1)
	   {  
	   medium_back(30);
		    if(gray_b1==1||gray_b2==1||gray_b3==1||gray_b5==1||gray_b6==1||gray_b7==1||gray_b8==1||gray_b9==1||gray_b10==1||gray_b11==1||gray_b12==1)
		   {
		  while(1)
			{
				backline_ts();
				
				
				if(gray_r==0)
				{
			 stop();
			 delay_ms(500);
			 Turn_R_Cross_back_1();
				stop();
				delay_ms(100);
                  break;					
				}
		    }
			 break;
		  }
	  }	    
}	
if(i==12)
{
i++;
	while(1)
  {
	findline();
	if(gray_a4==1&&gray_a7==1&&gray_a3==1&&gray_a10==1)		
	{
		N++;
		medium_go(50);
		delay_ms(200);
	}
	if(N==2)
	{
//	while(1) 
//	 {
	 stop();
	 delay_ms(100);//������ʱ���ԣ�����ת��
	 Turn_R_Cross_b();
		 break;
//   }break;
	} 
  }
  
  	while(1)
	{ 
	up();
		if(key2==0)
		{
		stopk1();
		break;
		}  
   }
  
}

if(i==13)
{
i++;
		/////////////////////////////////ץҩƷ//////////////
	while(1)
   {
    findline_ts();
	if(paotong1==0)
	{	
		delay_ms(500);
		stop();
		delay_ms(500);
		close();
		break;
	} 
   }
		while(1)
		{ 
		down();
			if(key1==0)
			{
			stopk1();
			break;
			}  
	    }	
		 while(1)
		{
		Turn_L_Cross_back_1();//////////////////////////////////////////////!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!���Ȳ���
			  break;
		}
		while(1)
		{
		  findline_ts();
			if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)
			{
			break;
			}
		}
}		
/////////////////////////�ڶ�����ǰ��Ѱǽ///////////////		

if(i==14)
{
i++;		
	while(1)
	{		
     medium_go(40);
	 delay_ms(1000);////////�����ٶȲ��ԣ�����
//	 delay_ms(300);
		break;
	}
	
	 while(1)
	{
		  adc12=Get_Adc_Average(ADC_Channel_14,10)/56;///////////////////////////////////////56Ϊ����ֵ�����в��ԣ�
		  OLED_ShowNum_NO_1(50,30,adc12,6,12);OLED_Refresh_Gram_NO_1();//��ʾADC��ֵ
     
          w=28-adc12;///////////////////25,���е���
		
		if(adc12>31)
		{
		w=-3; 
		}
		  j=w*5;
		  pwm3=27+j;//////////33���е���
	      go_wall2(pwm3);
		
		
		   while(1)
		{
		 if(gray_a2==1&&gray_a11==1)
		 {
		     stop();
			 delay_ms(200);
			 open();
			 delay_ms(200);
			  delay_ms(1000);
			 delay_ms(1000);
			 delay_ms(1000);
			 break;
		 }
		}break;
		 
	}		

/////////////////////////�ڶ��������Ѱǽ///////////////	
	  
			while(1)
	   {
		 pid=Speed_PID(adc13,Target_position);
		 adc10=Get_Adc_Average(ADC_Channel_13,10)/56;	   
         OLED_ShowNum_NO_1(50,10,adc10,6,12);OLED_Refresh_Gram_NO_1();		   
		 if(pid<0)
		 {
		 c=-pid*1.25;
		 OLED_ShowNum_NO_1(50,50,c,6,12);OLED_Refresh_Gram_NO_1();
		 m=pid;	 
		 pwm4=40+m;	
		 pwm_limit(pwm4);
//			 OLED_ShowNum_NO_1(50,30,pwm4,6,12);OLED_Refresh_Gram_NO_1();		 
		 }
		 if(pid>0||pid==0)
		 {
		 c=pid;
	     OLED_Refresh_Gram_NO_1();
		 OLED_ShowNum_NO_1(50,40,c,6,12);OLED_Refresh_Gram_NO_1();
		 pwm4=40+pid;	
		 pwm_limit(pwm4);
//		 OLED_ShowNum_NO_1(50,30,pwm4,6,12);OLED_Refresh_Gram_NO_1();		 
		 }    

		 
          if(adc10<=5)
		   {
		   break;
		   }			   			   		 
	   }
}
////////////////////////////�ؼ�//////////////////	   
if(i==15)
{
i++;
	      while(1)
	   {  
	   medium_back(30);
		    if(gray_b1==1||gray_b2==1||gray_b3==1||gray_b5==1||gray_b6==1||gray_b7==1||gray_b8==1||gray_b9==1||gray_b10==1||gray_b11==1||gray_b12==1)
			{
		  while(1)
			{
				backline_ts();
				if(gray_l==0)
				{
			 stop();
			 delay_ms(500);
			 Turn_L_Cross_back_1();
				stop();
				delay_ms(100);
                  break;					
				}
		    }
			 break;
		    }
	  }
   ////////////////////////׼���ص����//////////////
		while(1)
	   {
		findline();
		   if(gray_a2==1&&gray_a11==1&&gray_a3==1&&gray_a10==1)
		   {
		      stop();
			  delay_ms(200);
			  Turn_L_Cross();break;
		   }
	   } 
  	  while(1)
		{
		 findline();	
		 if(gray_a6==1&&gray_a7==1&&gray_a5==1&&gray_a8==1)
		 {
			medium_go(40);
			delay_ms(1000);
			 stop();
			break;
		 }	
		}
}

    while(1)
	{
	 stop();
	}	
	
}////choice

}/////while

}///////int

