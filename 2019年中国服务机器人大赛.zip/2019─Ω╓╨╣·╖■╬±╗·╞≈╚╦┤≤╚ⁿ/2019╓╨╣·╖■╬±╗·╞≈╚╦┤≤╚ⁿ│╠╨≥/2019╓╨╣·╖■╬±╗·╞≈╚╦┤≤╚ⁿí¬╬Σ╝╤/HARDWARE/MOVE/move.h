#ifndef __MOVE_H
#define __MOVE_H 
#include "sys.h"
void stop(void);
void medium_go(u16 go_stright);		
void medium_back(u16 pp);
void go_wall1(u16 pwm);
void go_wall2(u16 pwm);
void back_wall1(u16 pwm);
void back_wall2(u16 pwm);
void left_turn(u16 pwm_l);
void right_turn(u16 pwm_r);

void findline(void);
void Adjust_GrayF(void);
void Differential_R(float adjust);
void Differential_L(float adjust);
void Differential_base(u8 PWML,u8 PWMR);

void backline(void);	
void Adjust_GrayB(void);
void Differential_RB(float adjust);
void Differential_LB(float adjust);
void Differential_baseB(u8 PWML,u8 PWMR);

void Turn_L_Cross(void);
void Turn_R_Cross(void);
void Turn_R_Cross_x(void);
void Turn_R_Cross_b(void);
void Turn_R_Cross_back(void);
void Turn_L_Cross_back(void);
void Turn_L_Cross_r(void);
void Turn_R_Cross_r(void);
void Turn_L_Cross_z(void);
void Turn_R_Cross_last(void);
void Turn_R_Cross_back_1(void);
void Turn_L_Cross_back_1(void);
void Turn_R_Cross_back_2(void);
void Turn_R_Cross_back_z(void);
void Turn_R_Cross_z(void);
void Turn_L_Cross1(void);

int Speed_PID (int adc13,int Target);
void pwm_limit(int pwm);

void up(void);
void down(void);

void open(void);
void close(void);
void stopk1(void);

void Adjust_GrayB_ts(void);
void Adjust_GrayF_ts(void);

void findline_ts(void);
void backline_ts(void);

void findline_z(void);
void Adjust_GrayF_z(void);
void Differential_Rz(float adjust);
void Differential_Lz(float adjust);
void Differential_basez(u8 PWML,u8 PWMR);

void backline_z(void);
void Adjust_GrayB_z(void);
void Differential_LB_z(float adjust);
void Differential_RB_z(float adjust);
void Differential_baseB_z(u8 PWML,u8 PWMR);
#endif
