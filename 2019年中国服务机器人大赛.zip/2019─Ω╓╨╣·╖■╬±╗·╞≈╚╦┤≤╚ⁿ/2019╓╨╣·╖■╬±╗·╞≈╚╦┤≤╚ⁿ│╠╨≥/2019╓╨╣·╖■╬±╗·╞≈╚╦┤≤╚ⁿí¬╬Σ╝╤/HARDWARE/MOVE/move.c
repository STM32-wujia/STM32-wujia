#include "move.h"
#include "delay.h"
#include "led.h"
#include "adc.h"
#include "oled.h"

#define rS1 45
#define rS2 20



//��ǰѲ��//
void findline(void)	
{
  if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==1&&gray_a7==1&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(50);
	if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==1&&gray_a7==1&&gray_a8==1&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(50);
	if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==1&&gray_a6==1&&gray_a7==1&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(50);
	if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==1&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(50);
	if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==1&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(50);
	if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==1&&gray_a6==1&&gray_a7==1&&gray_a8==1&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(50);		
    
	else Adjust_GrayF();
}

//���ٵ���
void Adjust_GrayF(void)
{
//�Ҳ���
	     if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==1&&gray_a8==1&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_R(0.15);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==1&&gray_a8==1&&gray_a9==1&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_R(0.15);

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==1&&gray_a9==1&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_R(0.30);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==1&&gray_a9==1&&gray_a10==1&&gray_a11==0&&gray_a12==0)Differential_R(0.30);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==1&&gray_a10==1&&gray_a11==0&&gray_a12==0)Differential_R(0.45);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==1&&gray_a10==1&&gray_a11==1&&gray_a12==0)Differential_R(0.45);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==1&&gray_a11==1&&gray_a12==0)Differential_R(0.80);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==1&&gray_a11==1&&gray_a12==1)Differential_R(0.80);	
//�����
		
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==1&&gray_a6==1&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.15);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==1&&gray_a5==1&&gray_a6==1&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.15);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==1&&gray_a5==1&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.30);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==1&&gray_a4==1&&gray_a5==1&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.30);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==1&&gray_a4==1&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.45);
	else if(gray_a1==0&&gray_a2==1&&gray_a3==1&&gray_a4==1&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.45);	

	else if(gray_a1==0&&gray_a2==1&&gray_a3==1&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.80);
	else if(gray_a1==1&&gray_a2==1&&gray_a3==1&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_L(0.80);	
		
}

void Differential_R(float adjust)
{
	Differential_base(rS1*(1+adjust),rS1*(1-adjust));/////////�����ٶȴ������ٶ�С��������ת
}

void Differential_L(float adjust)
{
	Differential_base(rS1*(1-adjust),rS1*(1+adjust));//rS1=45
}

void Differential_base(u8 PWMR,u8 PWML)
{
	TIM3->CCR1=0;	
	TIM3->CCR2=PWMR;		  	             
	TIM3->CCR3=0; 	
	TIM3->CCR4=PWML;    	
}
///////////////////////////////////////////////////////////////////////

//���Ѳ��//
void backline(void)	
{
  if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==1&&gray_b7==1&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==1&&gray_b7==1&&gray_b8==1&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==1&&gray_b6==1&&gray_b7==1&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==1&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==0&&gray_b7==1&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
  if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==1&&gray_b6==1&&gray_b7==1&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
  if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==1&&gray_b7==1&&gray_b8==1&&gray_b9==1&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);	
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==1&&gray_b6==1&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);	
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==1&&gray_b6==1&&gray_b7==1&&gray_b8==1&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==1&&gray_b7==1&&gray_b8==1&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);
//	if(gray_b1==0&&gray_b2==0&&gray_b3==0&&gray_b5==0&&gray_b6==1&&gray_b7==1&&gray_b8==1&&gray_b9==1&&gray_b10==0&&gray_b11==0&&gray_b12==0)medium_back(30);	
		
     else Adjust_GrayB();
}

//���ٵ���
void Adjust_GrayB(void)
{
//�Ҳ���
	     if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==1&&gray_b8==1&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_RB(0.15);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==1&&gray_b8==1&&gray_b9==1&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_RB(0.15);

	else if(gray_b1==0&&gray_b2==0&&gray_a3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==1&&gray_b9==1&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_RB(0.25);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==1&&gray_b9==1&&gray_b10==1&&gray_b11==0&&gray_b12==0)Differential_RB(0.25);	

	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==1&&gray_b10==1&&gray_b11==0&&gray_b12==0)Differential_RB(0.45);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==1&&gray_b10==1&&gray_b11==1&&gray_b12==0)Differential_RB(0.45);	
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==1&&gray_b11==1&&gray_b12==0)Differential_RB(0.80);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==1&&gray_b11==1&&gray_b12==1)Differential_RB(0.80);	
//�����
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==1&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.15);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==1&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.15);
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.25);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.25);
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.45);
	else if(gray_b1==0&&gray_b2==1&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.45);	
		 
	else if(gray_b1==0&&gray_b2==1&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.80);
	else if(gray_b1==1&&gray_b2==1&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB(0.80);	
		
}

void Differential_LB(float adjust)
{
	Differential_baseB(rS1*(1+adjust),rS1*(1-adjust));
}

void Differential_RB(float adjust)
{
	Differential_baseB(rS1*(1-adjust),rS1*(1+adjust));
}

void Differential_baseB(u8 PWMR,u8 PWML)
{
	TIM3->CCR1=PWMR;	
	TIM3->CCR2=0;		          
	TIM3->CCR3=PWML; 	
	TIM3->CCR4=0;    	
}


////��ǰ��׼Ѳ��(�����ڽ϶�·��)
void findline_ts(void)	
{
    if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==1&&gray_a7==1&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_go(20);		
     else Adjust_GrayF_ts();
}

//���ٵ���
void Adjust_GrayF_ts(void)
{
//�Ҳ���
	     if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==1&&gray_a8==1&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Rz(0.55);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==1&&gray_a8==1&&gray_a9==1&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Rz(0.55);

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==1&&gray_a9==1&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Rz(0.75);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==1&&gray_a9==1&&gray_a10==1&&gray_a11==0&&gray_a12==0)Differential_Rz(0.75);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==1&&gray_a10==1&&gray_a11==0&&gray_a12==0)Differential_Rz(0.85);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==1&&gray_a10==1&&gray_a11==1&&gray_a12==0)Differential_Rz(0.85);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==1&&gray_a11==1&&gray_a12==0)Differential_Rz(0.95);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==1&&gray_a11==1&&gray_a12==1)Differential_Rz(0.95);
		
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==1&&gray_a12==1)Differential_Rz(1.00);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==1)Differential_Rz(1.00);
//�����
		
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==1&&gray_a6==1&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.55);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==1&&gray_a5==1&&gray_a6==1&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.55);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==1&&gray_a5==1&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.75);
	else if(gray_a1==0&&gray_a2==0&&gray_a3==1&&gray_a4==1&&gray_a5==1&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.75);	

	else if(gray_a1==0&&gray_a2==0&&gray_a3==1&&gray_a4==1&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.85);
	else if(gray_a1==0&&gray_a2==1&&gray_a3==1&&gray_a4==1&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.85);	

	else if(gray_a1==0&&gray_a2==1&&gray_a3==1&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.95);
	else if(gray_a1==1&&gray_a2==1&&gray_a3==1&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(0.95);
		
	else if(gray_a1==1&&gray_a2==1&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(1.00);
	else if(gray_a1==1&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==0&&gray_a7==0&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)Differential_Lz(1.00);
		
}

void Differential_Rz(float adjust)
{
	Differential_basez(rS2*(1+adjust),rS2*(1-adjust));/////////�����ٶȴ������ٶ�С��������ת
}

void Differential_Lz(float adjust)
{
	Differential_basez(rS2*(1-adjust),rS2*(1+adjust));
}

void Differential_basez(u8 PWML,u8 PWMR)
{
	TIM3->CCR1=0;	
	TIM3->CCR2=PWML;		                  
	TIM3->CCR3=0; 	
	TIM3->CCR4=PWMR;    	
}


////���׼Ѳ��(�����ڽ϶�·��)
void backline_ts(void)
{	
   	if(gray_a1==0&&gray_a2==0&&gray_a3==0&&gray_a4==0&&gray_a5==0&&gray_a6==1&&gray_a7==1&&gray_a8==0&&gray_a9==0&&gray_a10==0&&gray_a11==0&&gray_a12==0)medium_back(20);
	else Adjust_GrayB_ts();
}

void Adjust_GrayB_ts(void)
{
//�Ҳ���
	     if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==1&&gray_b8==1&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_RB_z(0.15);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==1&&gray_b8==1&&gray_b9==1&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_RB_z(0.15);

	else if(gray_b1==0&&gray_b2==0&&gray_a3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==1&&gray_b9==1&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_RB_z(0.25);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==1&&gray_b9==1&&gray_b10==1&&gray_b11==0&&gray_b12==0)Differential_RB_z(0.25);	

	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==1&&gray_b10==1&&gray_b11==0&&gray_b12==0)Differential_RB_z(0.35);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==1&&gray_b10==1&&gray_b11==1&&gray_b12==0)Differential_RB_z(0.35);	
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==1&&gray_b11==1&&gray_b12==0)Differential_RB_z(0.45);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==1&&gray_b11==1&&gray_b12==1)Differential_RB_z(0.45);	
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==1&&gray_b12==1)Differential_RB_z(0.60);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==1)Differential_RB_z(0.60);
//�����
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==1&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.15);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==1&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.15);
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.25);
	else if(gray_b1==0&&gray_b2==0&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==1&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.25);
		
	else if(gray_b1==0&&gray_b2==0&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.35);
	else if(gray_b1==0&&gray_b2==1&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.35);
		
	else if(gray_b1==0&&gray_b2==1&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.45);
	else if(gray_b1==1&&gray_b2==1&&gray_b3==1&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.45);	
		
	else if(gray_b1==1&&gray_b2==1&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.60);
	else if(gray_b1==1&&gray_b2==0&&gray_b3==0&&(gray_b4==0||gray_b4==1)&&gray_b5==0&&gray_b6==0&&gray_b7==0&&gray_b8==0&&gray_b9==0&&gray_b10==0&&gray_b11==0&&gray_b12==0)Differential_LB_z(0.60);
		
}


void Differential_LB_z(float adjust)
{
	Differential_baseB_z(rS2*(1+adjust),rS2*(1-adjust));
}

void Differential_RB_z(float adjust)
{
	Differential_baseB_z(rS2*(1-adjust),rS2*(1+adjust));
}

void Differential_baseB_z(u8 PWML,u8 PWMR)
{
	TIM3->CCR1=PWML;	
	TIM3->CCR2=0;		  
	                  
	TIM3->CCR3=PWMR; 	
	TIM3->CCR4=0;    	
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////��������///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




void medium_go(u16 go_stright)
{
	TIM_SetCompare1(TIM3,1);
	TIM_SetCompare2(TIM3,go_stright);
	TIM_SetCompare3(TIM3,1);
	TIM_SetCompare4(TIM3,go_stright);
}

void go_wall1(u16 pwm)//ǰ��
{
	TIM_SetCompare1(TIM3,1);
	TIM_SetCompare2(TIM3,30);
	TIM_SetCompare3(TIM3,1);
	TIM_SetCompare4(TIM3,pwm);
}


void go_wall2(u16 pwm)//ǰ��
{
	TIM_SetCompare1(TIM3,1);
	TIM_SetCompare2(TIM3,pwm);
	TIM_SetCompare3(TIM3,1);
	TIM_SetCompare4(TIM3,27);
}


void back_wall2(u16 pwm)//����
{
	TIM_SetCompare1(TIM3,27);
	TIM_SetCompare2(TIM3,1);
	TIM_SetCompare3(TIM3,pwm);
	TIM_SetCompare4(TIM3,1);
}

void back_wall1(u16 pwm)
{
	TIM_SetCompare1(TIM3,pwm);
	TIM_SetCompare2(TIM3,1);
	TIM_SetCompare3(TIM3,27);
	TIM_SetCompare4(TIM3,1);
}



void medium_back(u16 pp)
{
	TIM_SetCompare1(TIM3, pp);
	TIM_SetCompare2(TIM3,1);
	TIM_SetCompare3(TIM3, pp);
	TIM_SetCompare4(TIM3,1);
}

void stop(void)
{
	TIM_SetCompare1(TIM3,1);
	TIM_SetCompare2(TIM3,1);
	TIM_SetCompare3(TIM3,1);
	TIM_SetCompare4(TIM3,1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////ת�亯��///////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void left_turn(u16 pwm_l)
{
	TIM_SetCompare1(TIM3,pwm_l);
	TIM_SetCompare2(TIM3,1);
	TIM_SetCompare3(TIM3,1);
	TIM_SetCompare4(TIM3,pwm_l);
}

void right_turn(u16 pwm_r)
{
	TIM_SetCompare1(TIM3,1);
	TIM_SetCompare2(TIM3,pwm_r);
	TIM_SetCompare3(TIM3,pwm_r);
	TIM_SetCompare4(TIM3,1);
}


/////////////////////ÿ��ת�価������һ������////////////////////////////////////

 void Turn_R_Cross(void)//"T"����ת*1  
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);
			if(gray_r==0&&gray_l==0)
			{break;}
		}
	}
	while(1)
	{
		right_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(250);
		break;
	}
		while(1)
	{
		right_turn(30);
		if(gray_a3==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a3==1)
		  break;
		}
	}
}


 void Turn_R_Cross_b(void)//"T"����ת*1  
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);
			if(gray_r==0&&gray_l==0)
			{break;}
		}
	}
	while(1)
	{
		right_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(250);
		break;
	}
		while(1)
	{
		right_turn(30);
		if(gray_a5==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a5==1)
		  break;
		}
	}
}


 void Turn_R_Cross_x(void)//"T"����ת*1  �ڶ�����Ѱǽ
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);
			if(gray_r==0&&gray_l==0)
			{break;}
		}
	}
	while(1)
	{
		right_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(1000);
		
		break;
	}
		while(1)
	{
		right_turn(30);
		if(gray_a2==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{
			delay_ms(10);
			if(gray_a2==1)
		  break;
		}
	}
}


 void Turn_R_Cross_z(void)//"T"����ת*1  ��һ��ת��
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);
			if(gray_r==0&&gray_l==0)
			{break;}
		}
	}
	while(1)
	{
		right_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(400);
		break;
	}
		while(1)
	{
		right_turn(30);
		if(gray_a5==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a5==1)
		  break;
		}
	}
}




void Turn_R_Cross_last(void)//"T"����ת*1  ���һ��ת�䣨����ʱ���Ա���ɨ���ߣ�
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);
			if(gray_r==0&&gray_l==0)
			{break;}
		}
	}
	while(1)
	{
		right_turn(40);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(400);
		break;
	}
		while(1)
	{
		right_turn(40);
		if(gray_b6==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_b6==1)
		  break;
		}
	}
}


void Turn_R_Cross_back(void)//
{
	while(1)
	{
		right_turn(40);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(400);
		break;
	}
		while(1)
	{
		right_turn(40);
		if(gray_a4==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a4==1)
		  break;
		}
	}
}


void Turn_R_Cross_back_z(void)//
{
	while(1)
	{
		right_turn(40);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(400);
		break;
	}
		while(1)
	{
		right_turn(40);
		if(gray_a7==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a7==1)
		  break;
		}
	}
}


void Turn_R_Cross_back_1(void)//
{
	while(1)
	{
		right_turn(35);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(600);
		break;
	}
		while(1)
	{
		right_turn(25);
		if(gray_a8==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a8==1)
		  break;
		}
	}
}

void Turn_R_Cross_back_2(void)//
{
	while(1)
	{
		right_turn(35);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(500);
		break;
	}
		while(1)
	{
		right_turn(25);
		if(gray_a7==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a7==1)
		  break;
		}
	}
}




void Turn_L_Cross_back(void)//"T"����ת*1;"ʮ"����ת*1
{
	while(1)
	{
		left_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(400);
		break;
	}
		while(1)
	{
		left_turn(30);
		if(gray_a4==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a4==1)
		  break;
		}
	}
}

void Turn_L_Cross_back_1(void)//"T"����ת*1;"ʮ"����ת*1
{
	while(1)
	{
		left_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(500);
		break;
	}
		while(1)
	{
		left_turn(30);
		if(gray_a4==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(5);
			if(gray_a4==1)
		  break;
		}
	}
}


void Turn_L_Cross(void)//"T"����ת*1;"ʮ"����ת*1
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);/////����
			if(gray_r==0&&gray_l==0)
			{
			      break;
			}
		}
	}
	while(1)
	{
		left_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(500);
		break;
	}
		while(1)
	{
		left_turn(30);
		if(gray_a7==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�   
		{	
			delay_ms(10);
			if(gray_a7==1)
		  break;
		}
	}
}


void Turn_L_Cross_z(void)//�ؼҺ����ת��//
{
	while(1)
	{
		medium_back(40);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);/////����
			if(gray_r==0||gray_l==0)
			{
			      break;
			}
		}
	}
	while(1)
	{
		left_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(300);
		break;
	}
		while(1)
	{
		left_turn(30);
		if(gray_a6==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�        
		{	
			delay_ms(10);
			if(gray_a6==1)
		  break;
		}
	}
}


void Turn_L_Cross_r(void)//"T"����ת,��һ��Ѱ��ǽǰ��ת��
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);/////����
			if(gray_r==0&&gray_l==0)
			{
			      break;
			}
		}
	}
	while(1)
	{
		left_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(250);
		break;
	}
		while(1)
	{
		left_turn(30);
		if(gray_a10==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ� 
		{	
			delay_ms(10);
			if(gray_a10==1)
		  break;
		}
	}
}

void Turn_R_Cross_r(void)//"T"����ת*1;"ʮ"����ת*1
{
	while(1)
	{
		medium_go(30);
		delay_ms(1);
		if(gray_r==0&&gray_l==0)
		{
		 delay_ms(10);/////����
			if(gray_r==0&&gray_l==0)
			{
			      break;
			}
		}
	}
	while(1)
	{
		right_turn(30);/////////������ʱ���ԣ�����ת���ٶ�
		delay_ms(250);
		break;
	}
		while(1)
	{
		right_turn(30);
		if(gray_a3==1)/////////////���в��ԣ�ѡ���ʵ��ĻҶȵ�
		{	
			delay_ms(10);
			if(gray_a3==1)
		  break;
		}
	}
}

void Turn_L_Cross1(void)
{
	while(1)
	  {  
	left_turn(35);
	delay_ms(200);
		break;
	  }

}

////////////////////////////////////////////////////////////////////
void pwm_limit(int pwm)
{
 if(pwm>90)
 {
 pwm=90;
 }
 if(pwm<=0)
 {
  pwm=0;
 } 
 TIM_SetCompare1(TIM3,40);
 TIM_SetCompare2(TIM3,1);
 TIM_SetCompare3(TIM3,pwm);
 TIM_SetCompare4(TIM3,1);
 OLED_ShowNum_NO_1(50,30,pwm,6,12);OLED_Refresh_Gram_NO_1();
}


/**************************************************************************
�������ܣ�λ��ʽPID������
��ڲ���������������λ����Ϣ��Ŀ��λ��
����  ֵ�����PWM
����λ��ʽ��ɢPID��ʽ 
pwm=Kp*e(k)+Ki*��e(k)+Kd[e��k��-e(k-1)]
e(k)��������ƫ�� 
e(k-1)������һ�ε�ƫ��  
��e(k)����e(k)�Լ�֮ǰ��ƫ����ۻ���;����kΪ1,2,,k;
pwm�������
**************************************************************************/
int Speed_PID (int adc13,int Target)
{ 	
	 float Position_KP=2,Position_KI=0.005,Position_KD=10;
	 static float Bias,D_value,Integral_bias,Last_Bias;
	 adc13=Get_Adc_Average(ADC_Channel_13,10)/56;
	 Bias=adc13-Target;                                  //����ƫ��
	 Integral_bias+=Bias;	                                 //���ƫ��Ļ���
	 D_value=Position_KP*Bias+Position_KI*Integral_bias+Position_KD*(Bias-Last_Bias);       //λ��ʽPID������
	 Last_Bias=Bias;                                       //������һ��ƫ�� 
	 return D_value;                                           //�������
}                      


void up(void)////////�½�////
{
PCout(5)=1;
PCout(2)=0;	
}	

void down(void)//////����////
{
PCout(5)=0;
PCout(2)=1;	
}

void stopk1(void)////ֹͣ////
{
PCout(5)=1;
PCout(2)=1;	
}

void close(void)///צ�ӱպ�//
{
TIM_SetCompare1(TIM2,1780);
}
void open(void)///צ���ſ�//
{
TIM_SetCompare1(TIM2,1750);	
}
