#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0 PBout(5)// PB5
#define LED1 PEout(5)// PE5	


/*****************ǰ���Ҷȴ���������*****************/
#define gray_a1  PAin(5)
#define gray_a2  PAin(4)
#define gray_a3  PEin(12)
#define gray_a4  PEin(11)
#define gray_a5  PEin(14)
#define gray_a6  PEin(13)
#define gray_a7  PBin(12)
#define gray_a8  PEin(15)
#define gray_a9  PBin(14)
#define gray_a10 PBin(13)
#define gray_a11 PDin(8)
#define gray_a12 PBin(15)

/*****************�󷽻Ҷȴ���������*****************/
#define gray_b1  PDin(10)
#define gray_b2  PDin(9)
#define gray_b3  PDin(3)
#define gray_b4  PDin(0)
#define gray_b5  PDin(7)
#define gray_b6  PDin(4)
#define gray_b7  PBin(4)
#define gray_b8  PBin(3)
#define gray_b9  PBin(6)
#define gray_b10 PBin(5)
#define gray_b11 PEin(0)
#define gray_b12 PBin(7)

/******��Ҷ�*******/
#define gray_r PCin(13)

/******�һҶ�******/
#define gray_l PEin(6)


/*****�����******/
#define l_pwm1  PAout(7)
#define l_pwm2  PAout(6)

/*****�Ҳ���******/
#define r_pwm1  PBout(1)
#define r_pwm2  PBout(0)

/*****�������******/
#define l298_in1 PCout(2)
#define l298_in2 PCout(3)

/******������******/
#define infrared_a   PCin(5)
#define infrared_l_a PCin(0)
#define infrared_l_b PCin(1) 
#define infrared_b   PCin(2)
#define infrared_r_b PCin(3)
#define infrared_r_a PCin(4)

/*******���*******/
#define steering_pwm PAout(0)

/*******��Ͳ*******/
#define paotong1 PAin(15)//////ǰ////// 
#define paotong2 PDin(15) /////��//////

/*******��������*******/
#define key1 PAin(1)
#define key2 PAin(2)


/*******L298N�˿ں궨��*******/
#define IN1 PCout(2)
#define IN2 PFout(5)  
#define ENB TIM3->CCR2   

void LED_Init(void);//��ʼ��

		 				    
#endif


